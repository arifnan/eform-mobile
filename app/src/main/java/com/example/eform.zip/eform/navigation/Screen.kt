package com.example.eform.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Login : Screen("login")
    object Register : Screen("register")
    object Dashboard : Screen("dashboard")
    object CreateForm : Screen("create_form")
    object HistoryForm : Screen("history_form")
    object MyForm : Screen("my_form")
    object EditForm : Screen("edit_form/{formId}")
    object Profile : Screen("profile")
    object Notification : Screen ("notification")
    object Role : Screen("role")
    object LoginStudents : Screen("loginstudents")
    object RegisterStudents : Screen("registerstudents")

}