import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberImagePainter
import com.example.eform.navigation.Screen
import com.example.eform.ui.theme.EformTheme

@Composable
fun ProfileScreen(navController: NavController) {
    // Menggunakan mutableStateOf untuk menyimpan status dark mode
    val isDarkMode = remember { mutableStateOf(isSystemInDarkTheme()) }

    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var imageUri by remember { mutableStateOf<Uri?>(null) } // Menyimpan gambar profil
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri // Menyimpan gambar yang dipilih dari galeri
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {

        // Foto Profil
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(Color.Gray)
                .clickable {
                    pickImage.launch("image/*") // Membuka galeri untuk memilih gambar
                }
        ) {
            if (imageUri != null) {
                Image(painter = rememberImagePainter(imageUri), contentDescription = "Profile Picture", modifier = Modifier.fillMaxSize())
            } else {
                Icon(imageVector = Icons.Default.AccountCircle, contentDescription = "Profile", modifier = Modifier.fillMaxSize())
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Nama Pengguna
        Text(text = "Nama Pengguna", style = MaterialTheme.typography.h5)

        // Pengaturan mode terang/gela
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Mode Gelap")
            Switch(checked = isDarkMode.value, onCheckedChange = {
                isDarkMode.value = it // Mengubah nilai dark mode
                // Ganti tema (dark mode)
            })
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Ubah Password
        Text(text = "Ubah Password", style = MaterialTheme.typography.h6)

        OutlinedTextField(
            value = currentPassword,
            onValueChange = { currentPassword = it },
            label = { Text("Password Lama") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = newPassword,
            onValueChange = { newPassword = it },
            label = { Text("Password Baru") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Konfirmasi Password Baru") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Tombol Simpan Perubahan
        Button(onClick = {
            // Logika untuk menyimpan perubahan password
        }) {
            Text("Simpan Perubahan")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tombol Logout
        Button(
            onClick = {
                // Logika logout
                navController.navigate(Screen.Login.route) // Navigasi ke halaman login setelah logout
            },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
        ) {
            Text("Logout", color = Color.White)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ProfileScreenPreview() {
    EformTheme(darkTheme = true) {
        ProfileScreen(navController = rememberNavController())
    }
}

