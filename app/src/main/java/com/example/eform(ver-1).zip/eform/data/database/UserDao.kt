package com.example.eform.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.eform.data.model.UserEntity

//@Dao
//interface UserDao {
//    // Menyimpan user baru
//    @Insert
//    suspend fun insert(user: UserEntity)
//
//    // Mengambil user berdasarkan ID
//    @Query("SELECT * FROM user WHERE id = :id LIMIT 1")
//    suspend fun getUserById(id: Int): UserEntity?
//
//    // Mengupdate data user
//    @Update
//    suspend fun update(user: UserEntity)
//
//    // Menghapus user
//    @Query("DELETE FROM user WHERE id = :id")
//    suspend fun delete(id: Int)
//}

@Dao
interface UserDao {

    // Insert a new user
    @Insert
    suspend fun insert(user: UserEntity)

    // Get a user by email for login
    @Query("SELECT * FROM user WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    // Update an existing user's data (used for update profile)
    @Update
    suspend fun update(user: UserEntity)

    // Get all users (optional, for debugging or checking users)
    @Query("SELECT * FROM user")
    suspend fun getAllUsers(): List<UserEntity>

    // Delete all users (optional, for debugging)
    @Query("DELETE FROM user")
    suspend fun deleteAllUsers()
}