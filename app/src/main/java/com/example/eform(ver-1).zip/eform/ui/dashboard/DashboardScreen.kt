package com.example.eform.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.eform.data.api.RetrofitInstance
import com.example.eform.data.model.Form
import com.example.eform.navigation.Screen
import androidx.compose.material3.CardDefaults

@Composable
fun DashboardScreen(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    var forms by remember { mutableStateOf(listOf<Form>()) }
    var isLoading by remember { mutableStateOf(false) }
    var sortOrder by remember { mutableStateOf("asc") }

    val coroutineScope = rememberCoroutineScope()

    // Simulating loading data from API
    LaunchedEffect(Unit) {
        isLoading = true
        // Simulate loading from API
        try {
            val response = RetrofitInstance.api.getForms()  // assuming the function to get forms
            if (response.isSuccessful) {
                forms = response.body() ?: emptyList()
            }
        } catch (e: Exception) {
            // handle error
        }
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "E-Forms",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.weight(1f)
            )

            // Search bar
            BasicTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        // Implement search logic here if needed
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .background(Color.LightGray)
                    .padding(8.dp),
                textStyle = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Sorting controls (Ascending/Descending)
            TextButton(
                onClick = {
                    sortOrder = if (sortOrder == "asc") "desc" else "asc"
                    forms = forms.sortedBy { if (sortOrder == "asc") it.title else it.title.reversed() }
                }
            ) {
                Text(text = "Sort by Title ($sortOrder)")
            }

            // Add new form button
            FloatingActionButton(
                onClick = { navController.navigate(Screen.CreateForm.route) },
                modifier = Modifier.size(50.dp),
            ) {
                Text("+")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            CircularProgressIndicator()
        } else {
            // Display forms list
            LazyColumn {
                items(forms) { form: Form -> // pastikan tipe data `Form`
                    FormItem(form = form, onClick = {
                        navController.navigate(Screen.EditForm.route + "/${form.id}")
                    })
                }
            }
        }
    }
}

@Composable
fun FormItem(form: Form, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = form.title, style = MaterialTheme.typography.headlineSmall)
            Text(text = form.description ?: "No description", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Created: ${form.createdAt}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
