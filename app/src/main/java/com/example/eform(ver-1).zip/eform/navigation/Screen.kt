package com.example.eform.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Login : Screen("login")
    object Register : Screen("register")
    object Dashboard : Screen("dashboard")
    object CreateForm : Screen("create_form")
    object EditForm : Screen("edit_form/{formId}")
}