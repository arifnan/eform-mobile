package com.example.eform.utils

object Constants {
    const val BASE_URL = "https://e-form.ilta-services.tech/api/"
}