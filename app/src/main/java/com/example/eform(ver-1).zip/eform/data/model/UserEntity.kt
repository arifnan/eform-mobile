package com.example.eform.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")  // Nama tabel pada Room
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,  // Primary Key, autoGenerate berarti Room yang akan generate ID
    val name: String,
    val email: String,
    val password: String
)