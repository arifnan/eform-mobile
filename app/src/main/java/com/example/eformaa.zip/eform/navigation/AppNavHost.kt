package com.example.eform.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.eform.data.database.AppDatabase
import com.example.eform.ui.auth.OnboardingScreen
import com.example.eform.ui.splash.SplashScreen
import com.example.eform.ui.auth.LoginScreen // next step
import com.example.eform.ui.auth.LoginStudentsScreen
import com.example.eform.ui.auth.RegisterScreen
import com.example.eform.ui.auth.RegisterStudentsScreen
import com.example.eform.ui.auth.RoleSelectionScreen
import com.example.eform.ui.dashboard.DashboardScreen
import com.example.eform.ui.dashboard.DashboardScreenStudents
import com.example.eform.ui.form.CreateFormScreen
import com.example.eform.ui.form.FormAnswerScreen
import com.example.eform.ui.form.HistoryFormScreen
import com.example.eform.ui.form.MyFormsScreen
import com.example.eform.ui.form.PreviewFormScreen
import com.example.eform.ui.notification.NotificationScreen
import com.example.eform.ui.profile.ProfileScreen

@Composable
fun AppNavHost(navController: NavHostController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    val userDao = db.userDao()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(navController)
        }
        composable(Screen.Onboarding.route) {
            OnboardingScreen(navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController, userDao) // Beri userDao
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController, userDao) // Beri userDao
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(navController) // Pastikan navController diteruskan di sini
        }

        composable(Screen.DashboardStudents.route) {
            DashboardScreenStudents(navController) // Pastikan navController diteruskan di sini
        }

        composable(Screen.Profile.route) {
            ProfileScreen(navController)
        }
        composable(Screen.Notification.route) {
            NotificationScreen(navController)
        }
        composable(Screen.CreateForm.route) {
            CreateFormScreen(navController)
        }
        composable(Screen.HistoryForm.route) {
            HistoryFormScreen(navController)
        }
        composable(Screen.MyForm.route) {
            MyFormsScreen(navController)
        }

        composable(Screen.PreviewForm.route) { backStackEntry ->
            val formId = backStackEntry.arguments?.getString("formId")?.toInt() ?: 0
            PreviewFormScreen(formId = formId)
        }

        composable(
            "previewForm?formId={formId}",
            arguments = listOf(navArgument("formId") { type = NavType.IntType })
        ) { backStackEntry ->
            val formId = backStackEntry.arguments?.getInt("formId") ?: 0
            PreviewFormScreen(formId = formId)
        }


        composable(Screen.Role.route) {
            RoleSelectionScreen(navController)
        }

        composable(Screen.LoginStudents.route) {
            LoginStudentsScreen(navController, userDao) // Beri userDao
        }
        composable(Screen.RegisterStudents.route) {
            RegisterStudentsScreen(navController, userDao) // Beri userDao
        }
    }
}