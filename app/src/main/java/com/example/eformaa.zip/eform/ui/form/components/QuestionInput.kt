package com.example.eform.ui.form.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun QuestionInput(
    questionData: QuestionInputData,
    onDelete: () -> Unit
) {
    var questionText by remember { mutableStateOf(questionData.questionText) }
    var questionType by remember { mutableStateOf(questionData.questionType) }
    var options by remember { mutableStateOf(questionData.options.toMutableList()) }
    var required by remember { mutableStateOf(questionData.required) }

    var minScale by remember { mutableStateOf(questionData.minScale) }
    var maxScale by remember { mutableStateOf(questionData.maxScale) }
    var minLabel by remember { mutableStateOf(questionData.minLabel) }
    var maxLabel by remember { mutableStateOf(questionData.maxLabel) }

    // Sync kembali ke model
    LaunchedEffect(questionText, questionType, options, required, minScale, maxScale, minLabel, maxLabel) {
        questionData.questionText = questionText
        questionData.questionType = questionType
        questionData.options = options
        questionData.required = required
        questionData.minScale = minScale
        questionData.maxScale = maxScale
        questionData.minLabel = minLabel
        questionData.maxLabel = maxLabel
    }

    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = questionText,
                onValueChange = { questionText = it },
                label = { Text("Pertanyaan") },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            )

            DropdownMenuQuestionType(
                selectedType = questionType,
                onTypeSelected = { questionType = it }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (questionType) {
            QuestionType.MultipleChoice -> {
                Column {
                    options.forEachIndexed { index, option ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = false, onClick = null)
                            TextField(
                                value = option,
                                onValueChange = {
                                    val updated = options.toMutableList()
                                    updated[index] = it
                                    options = updated
                                },
                                placeholder = { Text("Opsi ${index + 1}") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent
                                )
                            )
                        }
                    }

                    TextButton(onClick = {
                        options = options.toMutableList().apply { add("") }
                    }) {
                        Text("➕ Tambahkan Opsi")
                    }
                }
            }

            QuestionType.Checkbox -> {
                Column {
                    options.forEachIndexed { index, option ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Checkbox(checked = false, onCheckedChange = null)
                            TextField(
                                value = option,
                                onValueChange = {
                                    val updated = options.toMutableList()
                                    updated[index] = it
                                    options = updated
                                },
                                placeholder = { Text("Opsi ${index + 1}") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent
                                )
                            )
                        }
                    }

                    TextButton(onClick = {
                        options = options.toMutableList().apply { add("") }
                    }) {
                        Text("➕ Tambahkan Opsi")
                    }
                }
            }

            QuestionType.LinearScale -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Skala: ")

                    // Minimum
                    DropdownSelector(
                        value = minScale,
                        range = 0..4,
                        onValueChange = { minScale = it }
                    )
                    Text(" sampai ")
                    // Maksimum
                    DropdownSelector(
                        value = maxScale,
                        range = 2..10,
                        onValueChange = { maxScale = it }
                    )
                }

                Row {
                    OutlinedTextField(
                        value = minLabel,
                        onValueChange = { minLabel = it },
                        label = { Text("$minScale Label (opsional)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = maxLabel,
                        onValueChange = { maxLabel = it },
                        label = { Text("$maxScale Label (opsional)") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            else -> {}
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Wajib diisi")
                Switch(
                    checked = required,
                    onCheckedChange = { required = it }
                )
            }

            IconButton(onClick = onDelete) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus Pertanyaan")
            }
        }
    }
}

@Composable
fun DropdownSelector(value: Int, range: IntRange, onValueChange: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(onClick = { expanded = true }) {
            Text("$value")
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            range.forEach { v ->
                DropdownMenuItem(
                    text = { Text("$v") },
                    onClick = {
                        onValueChange(v)
                        expanded = false
                    }
                )
            }
        }
    }
}


@Composable
fun DropdownMenuQuestionType(
    selectedType: QuestionType,
    onTypeSelected: (QuestionType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(onClick = { expanded = true }) {
            Text(selectedType.label)
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            QuestionType.values().forEach { type ->
                DropdownMenuItem(
                    text = { Text(type.label) },
                    onClick = {
                        onTypeSelected(type)
                        expanded = false
                    }
                )
            }
        }
    }
}

