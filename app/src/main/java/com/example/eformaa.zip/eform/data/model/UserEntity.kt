package com.example.eform.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0, // ID auto-generate
    val name: String, // Nama pengguna
    val email: String, // Email pengguna
    val nip: String, // NIP pengguna (untuk guru)
    val password: String, // Password yang disimpan dalam bentuk terenkripsi
    val role: String // Role pengguna, bisa "guru" atau "siswa"
)
