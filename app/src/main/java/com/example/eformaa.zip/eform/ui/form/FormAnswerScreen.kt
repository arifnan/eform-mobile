package com.example.eform.ui.form

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity
import com.example.eform.ui.form.components.QuestionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import com.example.eform.data.database.AppDatabase
import com.example.eform.data.database.FormDao
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FormAnswerScreen(formData: FormEntity) {
    val context = LocalContext.current
    var answers by remember { mutableStateOf(mutableMapOf<Int, String>()) }  // Untuk menyimpan jawaban
    var isFormValid by remember { mutableStateOf(true) }

    // Ambil formDao untuk mengakses database
    val formDao = AppDatabase.getDatabase(context).formDao()
    val questions = remember { mutableStateListOf<QuestionEntity>() }

    // Menggunakan LaunchedEffect untuk memuat data secara asinkron
    LaunchedEffect(formData.id) {
        // Memuat pertanyaan terkait dengan formId
        questions.clear()
        questions.addAll(formDao.getQuestionsForForm(formData.id))
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Tampilkan Judul dan Deskripsi Formulir
        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(6.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = formData.title, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = formData.description, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tampilkan semua pertanyaan dari Formulir
        questions.forEach { question ->
            QuestionPreview(questionData = question) { answer ->
                answers[question.id] = answer // Menyimpan jawaban untuk setiap pertanyaan
            }
        }

        // Tombol Kirim Jawaban
        Button(
            onClick = {
                if (validateForm(answers, formData, formDao)) {
                    Toast.makeText(context, "Formulir berhasil dikirim", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Mohon lengkapi semua pertanyaan", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) {
            Text(text = "Kirim Jawaban")
        }
    }
}

// Validasi jawaban dengan memuat pertanyaan menggunakan formDao
fun validateForm(answers: Map<Int, String>, formData: FormEntity, formDao: FormDao): Boolean {
    var isValid = true
    // Memanggil fungsi suspend di dalam coroutine atau LaunchedEffect
    GlobalScope.launch(Dispatchers.IO) {
        val questions = formDao.getQuestionsForForm(formData.id)
        isValid = questions.all { question ->
            !question.required || answers.containsKey(question.id) && answers[question.id]?.isNotBlank() == true
        }
    }
    return isValid
}

// Preview untuk pertanyaan
@Composable
fun QuestionPreview(questionData: QuestionEntity, onAnswerChange: (String) -> Unit) {
    var answer by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(8.dp)) {
        Text(text = questionData.questionText, style = MaterialTheme.typography.bodyMedium)

        when (questionData.questionType) {
            QuestionType.Text -> {
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it; onAnswerChange(answer) },
                    label = { Text("Jawaban Teks") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done)
                )
            }
            QuestionType.MultipleChoice -> {
                questionData.options.forEachIndexed { index, option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = answer == option, onClick = { answer = option; onAnswerChange(answer) })
                        Text(option)
                    }
                }
            }
            QuestionType.Checkbox -> {
                questionData.options.forEachIndexed { index, option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = answer.contains(option),
                            onCheckedChange = { checked ->
                                if (checked) {
                                    answer = answer + option
                                } else {
                                    answer = answer.replace(option, "")
                                }
                                onAnswerChange(answer)
                            }
                        )
                        Text(option)
                    }
                }
            }
            QuestionType.LinearScale -> {
                // Misalnya: menggunakan slider
                Slider(
                    value = answer.toFloatOrNull() ?: 0f,
                    onValueChange = { value -> answer = value.toString(); onAnswerChange(answer) },
                    valueRange = 0f..10f,
                    steps = 9
                )
                Text("Skala: $answer")
            }
        }
    }
}

// Ambil foto menggunakan kamera
fun takePhoto(context: Context) {
    val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    if (takePictureIntent.resolveActivity(context.packageManager) != null) {
        val photoFile: File = createImageFile(context)
        val photoUri: Uri = FileProvider.getUriForFile(context, "com.example.eform.fileprovider", photoFile)
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
        // Start Activity For Result
    }
}

// Membuat file gambar untuk foto
fun createImageFile(context: Context): File {
    val timestamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val storageDir: File = context.getExternalFilesDir(null)!!
    return File.createTempFile("JPEG_${timestamp}_", ".jpg", storageDir)
}