package com.example.eform.ui.components


import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.eform.ui.dashboard.*
import com.example.eform.ui.profile.ProfileScreen
import com.example.eform.ui.form.CreateFormScreen
import com.example.eform.ui.form.HistoryFormScreen
import com.example.eform.ui.form.MyFormsScreen

@Composable
fun BottomBarNavigation(navController: NavController) {
    var selectedIndex by remember { mutableStateOf(0) }

    Box(modifier = Modifier.fillMaxSize()) {
        // Tampilan berdasarkan item yang dipilih
        when (BottomBarItem.entries[selectedIndex]) {
            BottomBarItem.Home -> DashboardScreen(navController)  // Pass navController here
            BottomBarItem.MyForms -> MyFormsScreen(navController)
            BottomBarItem.Add -> CreateFormScreen(navController)
            BottomBarItem.History -> HistoryFormScreen(navController)
            BottomBarItem.Profile -> ProfileScreen(navController)
        }

        // Bottom bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            SimpleBottomNavigationBar(
                selectedIndex = selectedIndex,
                onItemSelected = { selectedIndex = it },
                navController = navController // Menyertakan navController ke bottom bar
            )
        }
    }
}

