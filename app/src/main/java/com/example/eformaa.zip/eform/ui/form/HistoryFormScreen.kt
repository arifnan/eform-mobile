package com.example.eform.ui.form

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.HistoricalChange
import androidx.navigation.NavController

@Composable
fun HistoryFormScreen(navController: NavController){
    Box(Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center)
    { Text("Riwayat") } }