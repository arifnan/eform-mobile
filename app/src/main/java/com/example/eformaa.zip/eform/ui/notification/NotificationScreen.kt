package com.example.eform.ui.notification

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun NotificationScreen(navController: NavController) {

}