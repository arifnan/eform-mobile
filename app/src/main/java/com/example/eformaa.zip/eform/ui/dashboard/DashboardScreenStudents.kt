package com.example.eform.ui.dashboard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.eform.data.database.AppDatabase
import com.example.eform.data.model.Form
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.Teacher
import com.example.eform.navigation.Screen
import com.example.eform.ui.components.SimpleBottomNavigationBarStudents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun DashboardScreenStudents(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    var forms by remember { mutableStateOf(sampleFormsStudents()) }
    var isLoading by remember { mutableStateOf(false) }
    var sortOrder by remember { mutableStateOf("asc") }

    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val formDao = db.formDao()

    var formCode by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp, top = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Profile",
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable {
                                navController.navigate(Screen.Profile.route)
                            }
                    )
                    Column(modifier = Modifier.padding(start = 5.dp)) {
                        Text(text = "hello, nanda", style = MaterialTheme.typography.titleMedium)
                        Text(text = "welcome back", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifikasi",
                    modifier = Modifier
                        .size(28.dp)
                        .clickable {
                            navController.navigate(Screen.Notification.route)
                        }
                )
            }
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFFFFFFFF))
                    .padding(16.dp)
            ) {
                // ✅ Tombol Akses Formulir (Ditambahkan)
                OutlinedTextField(
                    value = formCode,
                    onValueChange = { formCode = it },
                    label = { Text("Masukkan Kode Formulir") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(onClick = {
                    coroutineScope.launch {
                        val form = formDao.getFormByCode(formCode)
                        if (form != null) {
                            navController.navigate(Screen.FormAnswer.route.replace("{formId}", "${form.id}"))
                        } else {
                            Toast.makeText(context, "Kode formulir tidak valid", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) {
                    Text("Akses Formulir")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 🔎 Search bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.LightGray, shape = MaterialTheme.shapes.medium)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
                        textStyle = LocalTextStyle.current.copy(color = Color.Black),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text("cari formulir anda", color = Color.Gray)
                            }
                            innerTextField()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(onClick = {
                    sortOrder = if (sortOrder == "asc") "desc" else "asc"
                    forms = if (sortOrder == "asc") {
                        forms.sortedBy { it.title }
                    } else {
                        forms.sortedByDescending { it.title }
                    }
                }) {
                    Text("Sort by Title ($sortOrder)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (isLoading) {
                    CircularProgressIndicator()
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(forms) { form ->
                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .background(Color.LightGray, shape = MaterialTheme.shapes.medium)
                                    .clickable {
                                        navController.navigate(Screen.PreviewForm.route.replace("{formId}", "${form.id}"))
                                    }
                                    .padding(8.dp)
                            ) {
                                Text(text = form.title, color = Color.Black)
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            SimpleBottomNavigationBarStudents(
                selectedIndex = 0,
                onItemSelected = { selectedIndex -> },
                navController = navController
            )
        }
    )
}

fun sampleFormsStudents(): List<Form> {
    val teacher = Teacher(
        id = 1,
        name = "Ibu Lina",
        nip = 12345678,
        email = "lina@example.com",
        subject = "Bahasa Indonesia"
    )

    return listOf(
        Form(
            id = 1,
            title = "Formulir Observasi",
            description = "Observasi kelas 7A",
            teacher_id = teacher.id,
            createdAt = "2025-04-06",
            teacher = teacher
        ),
        Form(
            id = 2,
            title = "Form Evaluasi",
            description = "Evaluasi semester",
            teacher_id = teacher.id,
            createdAt = "2025-04-05",
            teacher = teacher
        )
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun DashboardPreviewStudents() {
    val dummyNavController = rememberNavController()
    DashboardScreenStudents(navController = dummyNavController)
}
