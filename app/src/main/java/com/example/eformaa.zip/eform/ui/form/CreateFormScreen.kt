package com.example.eform.ui.form

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.eform.data.database.AppDatabase
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity
import com.example.eform.ui.form.components.QuestionInput
import com.example.eform.ui.form.components.QuestionInputData
import com.example.eform.ui.form.components.QuestionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun CreateFormScreen(navController: NavController) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val questions = remember { mutableStateListOf<QuestionInputData>() }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Judul & Deskripsi", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("Judul Formulir") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Deskripsi") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            itemsIndexed(questions, key = { _, item -> item.id }) { index, item ->
                QuestionInput(
                    questionData = item,
                    onDelete = { questions.removeAt(index) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(100.dp)) // Space for FAB
            }
        }

        FloatingActionButton(
            onClick = { questions.add(QuestionInputData()) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Tambah Pertanyaan")
        }

        Button(
            onClick = {
                if (title.isBlank() || questions.isEmpty()) {
                    Toast.makeText(context, "Judul dan pertanyaan tidak boleh kosong", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val db = AppDatabase.getDatabase(context)
                val formDao = db.formDao()

                GlobalScope.launch(Dispatchers.IO) {
                    // Menghasilkan kode acak
                    val formCode = UUID.randomUUID().toString().take(8) // Menghasilkan kode acak 8 karakter
                    val formId = formDao.insertForm(FormEntity(title = title, description = description, formCode = formCode)).toInt()

                    // Menyimpan Pertanyaan yang terkait dengan formId
                    val questionEntities = questions.map {
                        QuestionEntity(
                            formId = formId,
                            questionText = it.questionText,
                            questionType = it.questionType,
                            options = it.options,
                            answer = "",
                            required = it.required
                        )
                    }

                    // Menyimpan pertanyaan ke dalam database
                    formDao.insertQuestions(questionEntities)

                    launch(Dispatchers.Main) {
                        Toast.makeText(context, "Formulir berhasil disimpan", Toast.LENGTH_SHORT).show()
                        navController.popBackStack()
                    }
                }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        ) {
            Text("Simpan Formulir")
        }
    }
}
