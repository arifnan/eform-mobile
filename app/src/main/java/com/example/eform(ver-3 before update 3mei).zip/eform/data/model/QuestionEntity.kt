package com.example.eform.data.model
//untuk local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.example.eform.ui.form.components.Converters
import com.example.eform.ui.form.components.QuestionType

@Entity(
    tableName = "questions",
    foreignKeys = [
        ForeignKey(
            entity = FormEntity::class,
            parentColumns = ["id"],
            childColumns = ["formId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
@TypeConverters(Converters::class)  // Menambahkan TypeConverter untuk enum
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val formId: Int,
    val questionText: String,
    val questionType: QuestionType,  // Enum untuk jenis pertanyaan
    var answer: String = ""  // Menyimpan jawaban, ubah ke var jika ingin diubah
)