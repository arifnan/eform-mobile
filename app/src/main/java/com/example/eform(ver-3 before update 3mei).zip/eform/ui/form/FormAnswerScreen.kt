package com.example.eform.ui.form

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity
import com.example.eform.ui.form.components.QuestionType

@Composable
fun FormAnswerScreen(formData: FormEntity, onSubmit: (List<Answer>) -> Unit) {
    val context = LocalContext.current
    var answers by remember { mutableStateListOf<Answer>() }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Tampilkan Judul dan Deskripsi
        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(6.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = formData.title, style = MaterialTheme.typography.h5)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = formData.description, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tampilkan dan isi pertanyaan formulir
        formData.questions.forEachIndexed { index, question ->
            QuestionInputForAnswer(questionData = question, onAnswerChange = { answer ->
                answers.add(Answer(question.id, answer))
            })
        }

        Button(onClick = {
            onSubmit(answers)
            Toast.makeText(context, "Jawaban berhasil dikirim", Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Kirim Jawaban")
        }
    }
}

@Composable
fun QuestionInputForAnswer(questionData: QuestionEntity, onAnswerChange: (String) -> Unit) {
    var answer by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(8.dp)) {
        Text(text = questionData.questionText, style = MaterialTheme.typography.h6)

        when (questionData.questionType) {
            QuestionType.Text -> {
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    label = { Text("Jawaban") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            QuestionType.MultipleChoice -> {
                questionData.options.forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = answer == option, onClick = { answer = option })
                        Text(option)
                    }
                }
            }
            QuestionType.Checkbox -> {
                questionData.options.forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = answer == option, onCheckedChange = { checked ->
                            answer = if (checked) option else ""
                        })
                        Text(option)
                    }
                }
            }
            QuestionType.LinearScale -> {
                Slider(
                    value = answer.toFloatOrNull() ?: 0f,
                    onValueChange = { value -> answer = value.toInt().toString() },
                    valueRange = 0f..10f,
                    steps = 9
                )
            }
        }
    }
}
