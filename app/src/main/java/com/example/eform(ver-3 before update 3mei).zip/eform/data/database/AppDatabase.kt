package com.example.eform.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity
import com.example.eform.data.model.UserEntity
import com.example.eform.ui.form.components.Converters

@Database(
    entities = [UserEntity::class, FormEntity::class, QuestionEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class) // Menambahkan TypeConverter untuk enum QuestionType
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun formDao(): FormDao
    abstract fun questionDao(): QuestionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "eform_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
