package com.example.eform.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material3.*
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.eform.navigation.Screen

// Enum untuk Bottom Bar
enum class BottomBarItem(val icon: ImageVector, val label: String) {
    Home(Icons.Default.Home, "Beranda"),
    MyForms(Icons.Default.List, "Form Saya"),
    Add(Icons.Default.Add, "Tambah"),
    History(Icons.Default.History, "Riwayat"),
    Profile(Icons.Default.Person, "Akun")
}


@Composable
fun SimpleBottomNavigationBar(
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    navController: NavController // Menambahkan navController ke dalam parameter
) {
    NavigationBar(
        modifier = Modifier.height(70.dp),
        containerColor = Color.White
    ) {
        BottomBarItem.values().forEachIndexed { index, item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                selected = selectedIndex == index,
                onClick = {
                    onItemSelected(index)
                    // Menambahkan aksi navigasi saat item dipilih
                    when (item) {
                        BottomBarItem.Home -> navController.navigate(Screen.Dashboard.route)
                        BottomBarItem.MyForms -> navController.navigate(Screen.MyForm.route)
                        BottomBarItem.Add -> navController.navigate(Screen.CreateForm.route)
                        BottomBarItem.History -> navController.navigate(Screen.HistoryForm.route)
                        BottomBarItem.Profile -> navController.navigate(Screen.Profile.route)
                    }
                }
            )
        }
    }
}


@Preview(showBackground = true)
@Composable
fun PreviewSimpleBottomNavigationBar() {
    val dummyNavController = rememberNavController()  // Buat dummy navController
    SimpleBottomNavigationBar(
        selectedIndex = 0,
        onItemSelected = { selectedIndex ->
            // Dummy action untuk preview
            println("Selected Index: $selectedIndex")
        },
        navController = dummyNavController  // Berikan dummyNavController ke navController
    )
}