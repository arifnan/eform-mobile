package com.example.eform.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.eform.data.database.AppDatabase
import com.example.eform.ui.auth.OnboardingScreen
import com.example.eform.ui.splash.SplashScreen
import com.example.eform.ui.auth.LoginScreen // next step
import com.example.eform.ui.auth.RegisterScreen
import com.example.eform.ui.dashboard.DashboardScreen
import com.example.eform.ui.form.CreateFormScreen
import com.example.eform.ui.form.HistoryFormScreen
import com.example.eform.ui.notification.NotificationScreen
import com.example.eform.ui.profile.ProfileScreen

@Composable
fun AppNavHost(navController: NavHostController) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }
    val userDao = db.userDao()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(navController)
        }
        composable(Screen.Onboarding.route) {
            OnboardingScreen(navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController, userDao) // Beri userDao
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController, userDao) // Beri userDao
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(navController) // Pastikan navController diteruskan di sini
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController)
        }
        composable(Screen.Notification.route) {
            NotificationScreen(navController)
        }
        composable(Screen.CreateForm.route) {
            CreateFormScreen(navController)
        }
        composable(Screen.HistoryForm.route) {
            HistoryFormScreen(navController)
        }
        composable(Screen.MyForm.route) {
            HistoryFormScreen(navController)
        }
    }
}