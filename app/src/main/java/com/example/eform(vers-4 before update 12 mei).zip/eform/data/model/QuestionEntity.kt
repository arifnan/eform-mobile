package com.example.eform.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.eform.ui.form.components.QuestionType

@Entity(
    tableName = "questions",
    foreignKeys = [
        ForeignKey(
            entity = FormEntity::class,
            parentColumns = ["id"],
            childColumns = ["formId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val formId: Int,
    val questionText: String,
    val questionType: QuestionType,
    val options: String,  // Ganti menjadi String untuk disimpan sebagai JSON
    val answer: String,
    val required: Boolean = false
)
