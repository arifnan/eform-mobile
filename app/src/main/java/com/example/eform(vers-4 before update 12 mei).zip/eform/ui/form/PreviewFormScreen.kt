package com.example.eform.ui.form

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity
import com.example.eform.ui.form.components.QuestionType

@Composable
fun PreviewFormScreen(formData: FormEntity) {
    // Pastikan formData.questions ada dan valid
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Tampilkan Judul dan Deskripsi
        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(6.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = formData.title, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = formData.description, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tampilkan pertanyaan formulir
        formData.questions.forEach { question ->
            QuestionPreview(questionData = question)
        }
    }
}

@Composable
fun QuestionPreview(questionData: QuestionEntity) {
    Column(modifier = Modifier.padding(8.dp)) {
        Text(text = questionData.questionText, style = MaterialTheme.typography.bodyMedium)

        when (questionData.questionType) {
            QuestionType.Text -> {
                Text("Jawaban: ${questionData.answer}") // Tampilkan jawaban teks
            }
            QuestionType.MultipleChoice -> {
                // Tampilkan pilihan ganda
                questionData.options.forEach { option ->
                    Text("Option: $option")
                }
            }
            QuestionType.Checkbox -> {
                // Tampilkan checkbox
                questionData.options.forEach { option ->
                    Text("Option: $option")
                }
            }
            QuestionType.LinearScale -> {
                // Tampilkan slider
                Text("Skala: ${questionData.answer}")
            }
        }
    }
}
