package com.example.eform.data.database
//untuk lokal
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.eform.data.model.FormEntity
import com.example.eform.data.model.QuestionEntity

@Dao
interface FormDao {

//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    suspend fun insertForm(form: FormEntity): Long
//
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    suspend fun insertQuestions(questions: List<QuestionEntity>)
//
//
//    @Query("SELECT * FROM forms ORDER BY createdAt DESC")
//    suspend fun getAllForms(): List<FormEntity>
//
//    @Query("SELECT * FROM questions WHERE formId = :formId")
//    suspend fun getQuestionsForForm(formId: Int): List<QuestionEntity>
//

    @Insert
    suspend fun insertForm(form: FormEntity)

    @Transaction
    @Query("SELECT * FROM forms WHERE id = :formId")
    suspend fun getFormWithQuestions(formId: Int): FormEntity

}